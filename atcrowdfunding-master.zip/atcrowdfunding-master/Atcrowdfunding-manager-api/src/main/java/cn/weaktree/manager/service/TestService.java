package cn.weaktree.manager.service;

public interface TestService {

    public void insert();

}
