package cn.weaktree.manager.service;


import cn.weaktree.bean.User;

import java.util.HashMap;

public interface UserService {
    User login(HashMap<String, Object> paramMap);
}
