package cn.weaktree.manager.dao;

import java.util.Map;

public interface TestDao {

    public void insert(Map map);

}
