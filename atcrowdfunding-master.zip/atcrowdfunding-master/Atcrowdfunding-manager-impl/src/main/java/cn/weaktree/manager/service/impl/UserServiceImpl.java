package cn.weaktree.manager.service.impl;

import cn.weaktree.bean.User;
import cn.weaktree.manager.dao.UserMapper;
import cn.weaktree.manager.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import cn.weaktree.exception.LoginFailException;

import java.util.HashMap;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    @Override
    public User login(HashMap<String, Object> paramMap) {

        User user =  userMapper.login(paramMap);

        if(user==null){
            throw new LoginFailException("登陆失败");
        }

        return user;

    }
}
