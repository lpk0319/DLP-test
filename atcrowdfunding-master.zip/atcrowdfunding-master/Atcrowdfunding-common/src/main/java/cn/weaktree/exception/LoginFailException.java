package cn.weaktree.exception;

public class LoginFailException extends RuntimeException {


    public LoginFailException(String message) {
        super(message);
    }
}
