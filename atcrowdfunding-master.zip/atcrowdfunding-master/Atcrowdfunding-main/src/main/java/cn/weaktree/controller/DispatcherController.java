package cn.weaktree.controller;

import cn.weaktree.bean.User;
import cn.weaktree.manager.service.UserService;
import cn.weaktree.util.AjaxResult;
import cn.weaktree.util.Const;
import cn.weaktree.util.MD5Util;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.util.HashMap;

@Controller
public class DispatcherController {

    @Autowired
    private UserService userService;

    @RequestMapping("/index")
    public String index(){
        return "index";
    }

    @RequestMapping("/login")
    public String login(){
        return "login";
    }

    @RequestMapping("/main")
    public String main(){
        return "main";
    }

    @RequestMapping("/logout")
    public String logout(HttpSession session){

        session.invalidate();//销毁session对象，或清理session域

        return "redirect:/index.htm";
    }


    //异步请求
    //@ResponseBody结合jackson组建麻将结果转换为字符串，将json穿以流的形式返回给客户端
    @ResponseBody
    @RequestMapping("/dologin")
    public Object doLogin(String loginacct, String userpswd, String type, HttpSession session){

        AjaxResult result = new AjaxResult();

        try{
            HashMap<String, Object> paramMap = new HashMap<>();
            paramMap.put("loginacct",loginacct);
            paramMap.put("userpswd", MD5Util.digest(userpswd));
            paramMap.put("type",type);

            System.out.println(paramMap);

            User user = userService.login(paramMap);

            session.setAttribute(Const.LOGIN_USER,user);

            result.setSuccess(true);
            //{"success":true}
        }catch (Exception e){
            result.setReason("登录失败");
            e.printStackTrace();
            result.setSuccess(false);
            //{"success":false,"message":"登陆失败！"}
        }

        return result;

    }

    //同步请求
    /*@RequestMapping("/dologin")
    public String doLogin(String loginacct, String userpswd, String type, HttpSession session){
        HashMap<String, Object> paramMap = new HashMap<>();
        paramMap.put("loginacct",loginacct);
        paramMap.put("userpswd",userpswd);
        paramMap.put("type",type);

        User user = userService.login(paramMap);

        session.setAttribute(Const.LOGIN_USER,user);
        //为什么不直接main，因为直接main在刷新页面时会转发操作，会重复提交表单
        //用重定向
        return "redirect:/main.htm";

    }*/
}
