package test;

public class Test03 {

    public static void main(String[] args) throws Exception {
        //String str = null;
        //str.toUpperCase();//成员方法：依赖于对象才能调用的

        //Thread t = null;
        //t.sleep(3000);//静态方法，正常是通过类名称来调用(Thread.sleep(3000))，而不推荐用对象来调用

        String i = null;







    }

}
